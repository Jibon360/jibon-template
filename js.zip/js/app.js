$(document).ready(function () {
    $(window).on('scroll', function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $("nav").addClass("nav-bg");
        } else {
            $("nav").removeClass("nav-bg");
        }


    });


    var typed = new Typed('.element', {
        strings: ['WEB DESIGNER', 'WEB DEVELOPER', 'GRAPHICS DESIGNER'],
        smartBackspace: true,
        backSpeed: 100,
        backDelay: 500,
        startDelay: 1000,
        loop: true,
        loopCount: Infinity,
        typeSpeed: 100


    });






    $("#nav-btn").click(function () {
        $("#nav-icon").toggleClass("fa-xmark");

    });



    $('.demo').ripples({

        // Image Url
        imageUrl: null,

        // The width and height of the WebGL texture to render to. 
        // The larger this value, the smoother the rendering and the slower the ripples will propagate.
        resolution: 256,

        // The size (in pixels) of the drop that results by clicking or moving the mouse over the canvas.
        dropRadius: 20,

        // Basically the amount of refraction caused by a ripple. 
        // 0 means there is no refraction.
        perturbance: 0.04,

        // Whether mouse clicks and mouse movement triggers the effect.
        interactive: true,

        // The crossOrigin attribute to use for the affected image. 
        crossOrigin: ''

    });



    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function () {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })()



    $('#owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })


    $('.test-popup').magnificPopup({
        type: 'image',
        // other options
        removalDelay: 300,
        gallery: {
            // options for gallery
            enabled: true
        },
    });



    var mixer = mixitup(".filter-gallery");


});